clc;
clear;

%read composition information/descriptors
feature = xlsread('XXX'); %XXX stands for the file&range to read

n=length(feature(1,:));

for i=1:n
    feature_n(:,i)=rescale(feature(:,i));
end

[coeff,score,latent]=pca(feature_n);

PC1=score(:,1);
PC2=score(:,2);

PC=cat(2,PC1,PC2); %the first two princple component