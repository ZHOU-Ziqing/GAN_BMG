%Kernel smoothing function estimate
clc;
clear;

X=xlsread(XXX);%one could read the PC value 1D/2D
Dim=min(size(X));

if Dim==1
    %1D kernel density
    pts1=[500:10:1300];
    [f,xi]=ksdensity(X,pts1');
elseif Dim==2
    %2D kernel density
    refx=[-1:0.05:1];% one could modify the range of x
    refy=[-0.5:0.05:1.5];% one could modify the range of y
    a=0;
    for i=1:length(refx)
        for j=1:length(refy)
            a=a+1;
            pts2(1,a)=refx(i);
            pts2(2,a)=refy(j);
        end
    end
    [f,xi]=ksdensity(X,pts2');
end


