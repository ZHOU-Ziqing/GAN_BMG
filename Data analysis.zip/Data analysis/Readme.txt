*This fold cantains the codes of data analysis
##One could use PCA.m to process principle component analysis, the output is PC1 and PC2.

##One could use kerneldensity.m to process kernel smoothing, the input is PC1 and/or PC2. The output is the density mapping [f,xi].
