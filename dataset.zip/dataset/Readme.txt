*This fold cantains the data for GAN training
##One could follow the procedure to generate the dataset for GAN training
1. Use the "descriptor_vector" file to generate the .mat file.
2. In the fold "matlab files for GAN training", all datasets have been generated for GAN training.

##Reference
[1]	Z. Long, H. Wei, Y. Ding, P. Zhang, G. Xie, A. Inoue, J. Alloys Compd. 475 (2009) 207–219.
[2]	Z.Z. Yuan, S.L. Bao, Y. Lu, D.P. Zhang, L. Yao, J. Alloys Compd. 459 (2008) 251–260.
[3]	S. Guo, C.T. Liu, Intermetallics 18 (2010) 2065–2068.
[4]	L. Ward, S.C. O’Keeffe, J. Stevick, G.R. Jelbert, M. Aykol, C. Wolverton, Acta Mater. 159 (2018) 102–111.
[5]	W.Y. Liu, H.F. Zhang, A.M. Wang, H. Li, Z.Q. Hu, Mater. Sci. Eng. A 459 (2007) 196–203.
[6]	Z. Long, W. Liu, M. Zhong, Y. Zhang, M. Zhao, G. Liao, Z. Chen, J. Therm. Anal. Calorim. 132 (2018) 1645–1660.
[7]	J.-L. Gu, Y. Shao, K.-F. Yao, Materialia 8 (2019) 100433.
[8]	J. Xiong, T.Y. Zhang, S.Q. Shi, MRS Commun. 9 (2019) 576–585.
[9]	T. Wada, J. Jiang, K. Yubuta, H. Kato, A. Takeuchi, Materialia 7 (2019) 100372.
[10]	Z.P. Lu, H. Bei, C.T. Liu, Intermetallics 15 (2007) 618–624.
[11]	W.L. Johnson, J.H. Na, M.D. Demetriou, Nat. Commun. 7 (2016).
[12]	A. Takeuchi, K. Amiya, T. Wada, K. Yubuta, W. Zhang, A. Makino, Mater. Trans. 55 (2014) 165–170.
[13]	A.P. Tsai, A. Inoue, T. Masumoto, Metall. Trans. A 19 (1988) 1369–1371.
[14]	T. Komatsu, J. Non. Cryst. Solids 185 (1995) 199–202.

