clc;
clear;
% Zr=1; Cu=2; Al=3; Ni=4; Ag=5; Ti=6; Nb=7; Co=8;%Zr compositions
% Fe=1; B=2; C=3; Si=4; Mo=5; P=6; Y=7; Co=8; Cr=9; Nb=10;%Fe compositions
% Ti=1; Cu=2; Ni=3; Zr=4; Be=5; Sn=6; Si=7; B=8;%Ti compositions
% La=1; Al=2; Cu=3; Ni=4; Ag=5; Co=6; Ce=7; Mg=8;%La compositions properties
% Zr=1; Cu=2; Al=3; Ni=4; Ag=5; Ti=6; Nb=7; Fe=8; %Zr properties
% Zr=1; Ti=2; Cu=3; Ni=4; Al=5; Nb=6; Ag=7; Hf=8; %Hybrid

ele_no=8;% put in 8 for Zr, La, Ti; put in 10 for Fe.

%read the range for D1
[num,txt] = xlsread('Zr_BMG.xlsx',1,'B2:D200'); % read the compositions

% fea=true; %use this for D1
fea=false; %use this for CD1-CD3

%read the range for D2, D3, depend on the requirement
if fea 
    features = xlsread('Zr_BMG.xlsx',1,'E2:L2160'); %read the descriptor
    fea_no=length(features(1,:));
end

component=txt(:,1);% each componet in each alloy

fraction=txt(:,2);% each fraction in each alloy

No=num;%number of elements in each alloy

Num=length(component);% number of types of alloys


Vect=zeros(ele_no,Num); % information initialization

for i=1:Num

    Com(i) = regexp(component(i), '\s+', 'split');
    s=Com{i};
    Fra(i) = regexp(fraction(i), '\s+', 'split');
    s=Com{i};
    t=Fra{i};
    comp=zeros(No(i),1);
    ele_frac=zeros(No(i),1);
    for j=1:No(i)
        comp(j)=eval(cell2mat(s(j)));%transfer the data of components
        ele_frac(j)=eval(cell2mat(t(j)));%transfer the data of fractions
        for k=1:ele_no
            if k==comp(j)
                Vect(k,i)=ele_frac(j);
            end
        end
        if fea
            for L=1:fea_no
                Vect(ele_no+L,i)=features(i,L);
            end
        end

    end
end

for i=1:Num

    Vect(1:ele_no,i)=Vect(1:ele_no,i)/sum(Vect(1:ele_no,i));

end

Vector = Vect;

if fea
    for i=1:fea_no
        Vector(ele_no+i,:)=Vector(ele_no+i,:)/max(abs(Vect(ele_no+i,:)));
    end
end

V4D(:,1,1,:)=Vector;

save('Zr_BMG_CD1','V4D','Vect');


