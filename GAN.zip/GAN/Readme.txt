*This fold cantains the codes of GAN training, reading and evaluating
##One could follow the procedure to generate the BMG compositions:
1. Use the "Start_GAN.m" file to train the GAN and get 100 .mat files (default).
2. Use the "Read_compositions.m" to read the 100 files and write into an .xls file.
3. One could read the generator loss by reading "loss" in the workspace.

## Reference
1. `https://grzegorzgwardys.wordpress.com/2016/04/22/8/`
2. `Dumoulin V, Visin F. A guide to convolution arithmetic for deep learning[J]. 2016.`
3. `https://github.com/rasmusbergpalm/DeepLearnToolbox/tree/master/CNN`
4. `http://neuralnetworksanddeeplearning.com/index.html`