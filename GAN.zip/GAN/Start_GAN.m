clear;
clc;
% -----------load BMG data
load('ZrBMG_D1', 'V4D');%load XXX.mat in '/dataset/matlab' files for GAN training 

train_x=V4D;
batch_size = 1;
Size=size(V4D);

% ---------- model
for i=1:100 % 100 compositions
    %the parameters of generator could be multified here
    generator.layers = {
        struct('type', 'input', 'output_shape', [100, batch_size]) 
        struct('type', 'fully_connect', 'output_shape', [1000, batch_size], 'activation', 'leaky_relu')
        struct('type', 'fully_connect', 'output_shape', [Size(1), batch_size], 'activation', 'sigmoid') 
        struct('type', 'reshape', 'output_shape', [Size(1), 1, 1, batch_size])
    };
    %the parameters of discriminator could be multified here
    discriminator.layers = {
        struct('type', 'input', 'output_shape', [Size(1),1,1, batch_size])
        struct('type', 'reshape', 'output_shape', [Size(1), batch_size])
        struct('type', 'fully_connect', 'output_shape', [1000, batch_size], 'activation', 'leaky_relu')
        struct('type', 'fully_connect', 'output_shape', [1, batch_size], 'activation', 'sigmoid')
    };
end
args = struct('batch_size', batch_size, 'epoch', 100, 'learning_rate', 0.001, 'optimizer', 'adam');

%100 training files (x.mat) will be saved
for i=1:100
    [generator_trained(i), discriminator_trained(i),gen_loss,dis_loss] = gan_train(generator, discriminator, train_x, args,i);
end

%record loss
loss=cat(2,gen_loss,dis_loss);